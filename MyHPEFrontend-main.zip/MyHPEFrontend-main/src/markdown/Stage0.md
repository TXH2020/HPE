#Interactive Embedded Web Terminal(IEWT) Interactive Playbook Demonstration
																																																
```bash
hostname
```
```bash
sleep 5
```
```bash
sleep 20
```
```bash
hostname2
```	
```bash
script
```	
```bash
uname -a
```	
```bash
exit
```
```bash
read -s hello_var
```
```bash
script
```	
```bash
echo $hello_var
```	
```bash
exit
```	